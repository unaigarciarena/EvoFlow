import numpy as np
import matplotlib.pyplot as plt

evolution = np.load("/home/unai/Escritorio/EvoFlow/simple_res.npy")[:10000]
random = np.load("/home/unai/Escritorio/EvoFlow/simple_res_rand.npy")[:10000]

for i in range(evolution.shape[0]-1):
    evolution[i+1] = np.min([evolution[i], evolution[i+1]])
    random[i + 1] = np.min([random[i], random[i + 1]])

plt.plot(np.log(evolution), label="Evoflow")
plt.plot(np.log(random), label="Random")
plt.legend()
plt.ylabel(r"$log(accuracy error)$")
plt.xlabel("Evaluations")
plt.show()